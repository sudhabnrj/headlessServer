import express from "express";
import axios from "axios";
import cors from "cors";
import dotenv from "dotenv";
import braintree from "braintree";
import cookieParser from "cookie-parser";

dotenv.config();

const app = express();
const PORT = process.env.PORT;

app.use(
  cors({
    origin: "http://localhost:5173", // or your frontend URL
    credentials: true, // 🔥 VERY IMPORTANT
  })
);
app.use(cookieParser());
app.use(express.json());

// BigCommerce API Credentials
const BASE_URL = `https://api.bigcommerce.com/stores/${process.env.VITE_APP_STORE_ID}/v3`;
const STOREFRONT_CART_URL = `https://api.bigcommerce.com/stores/${process.env.VITE_APP_STORE_ID}/v3/carts`;
const BASE_URLV2 = `https://api.bigcommerce.com/stores/${process.env.VITE_APP_STORE_ID}/v2`;
const ACCESS_TOKEN = process.env.VITE_APP_ACCESS_TOKEN;
const STORE_HASH = process.env.VITE_APP_STORE_ID;
const KLAVIYO_API_URL = "https://a.klaviyo.com";
const KLAVIYO_API_KEY = process.env.KLAVIYO_API_KEY;
const BIGCOMMERCE_TOKEN = process.env.VITE_APP_JWT_TOKEN;
//Braintree setup
const gateway = new braintree.BraintreeGateway({
  environment: braintree.Environment.Sandbox, // Change to .Production for live payments
  merchantId: process.env.BRAINTREE_MERCHANT_ID,
  publicKey: process.env.BRAINTREE_PUBLIC_KEY,
  privateKey: process.env.BRAINTREE_PRIVATE_KEY,
});

const headers = {
  "X-Auth-Token": ACCESS_TOKEN,
  "Content-Type": "application/json",
  Accept: "application/json",
};

// Reusable function to fetch data from BigCommerce API
const fetchBigCommerceData = async (endpoint, res) => {
  try {
    console.log(`Fetching data from: ${BASE_URL}/${endpoint}`);

    const response = await axios.get(`${BASE_URL}/${endpoint}`, {
      headers: {
        "X-Auth-Token": ACCESS_TOKEN,
        "Content-Type": "application/json",
      },
    });

    res.json(response.data);
  } catch (error) {
    console.error(
      `Error fetching ${endpoint}:`,
      error.response?.data || error.message
    );
    res.status(error.response?.status || 500).json({
      error: `Failed to fetch ${endpoint}`,
      details: error.response?.data || error.message,
    });
  }
};

//Add the Shipping Method API
app.post("/api/checkouts/:id/consignments", async (req, res) => {
  const checkoutId = req.params.id;
  const consignments = req.body;

  if (!consignments || consignments.length === 0) {
    return res.status(400).json({ error: "Consignments data is required" });
  }

  try {
    console.log(`Submitting shipping method for Checkout ID: ${checkoutId}`);

    const response = await axios.post(
      `${BASE_URL}/checkouts/${checkoutId}/consignments?include=consignments.available_shipping_options`,
      consignments,
      {
        headers: {
          "X-Auth-Token": ACCESS_TOKEN,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      }
    );

    res.json(response.data);
  } catch (error) {
    console.error(
      "Error submitting shipping method:",
      error.response?.data || error.message
    );
    res.status(error.response?.status || 500).json({
      error: "Failed to submit shipping method",
      details: error.response?.data || error.message,
    });
  }
});

// DELETE: /api/checkouts/:checkoutId/consignments/:consignmentId
app.delete(
  "/api/checkouts/:checkoutId/consignments/:consignmentId",
  async (req, res) => {
    const { checkoutId, consignmentId } = req.params;
    const { version } = req.body;

    if (!checkoutId || !consignmentId || version === undefined) {
      return res.status(400).json({
        error: "Missing checkoutId, consignmentId, or version in request.",
      });
    }

    try {
      const response = await axios.delete(
        `${BASE_URL}/checkouts/${checkoutId}/consignments/${consignmentId}`,
        {
          headers: {
            "X-Auth-Token": ACCESS_TOKEN,
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          data: { version }, // Axios allows sending a body with DELETE via `data`
        }
      );

      res.status(200).json({
        message: `Successfully deleted consignment ${consignmentId}`,
        data: response.data,
      });
    } catch (error) {
      console.error(
        "Error deleting consignment:",
        error?.response?.data || error.message
      );
      res.status(error?.response?.status || 500).json({
        error: "Failed to delete consignment",
        details: error?.response?.data || error.message,
      });
    }
  }
);

//Update Shipping Method API
app.put(
  "/api/checkouts/:checkoutId/consignments/:consignmentId",
  async (req, res) => {
    const { checkoutId, consignmentId } = req.params;
    const consignmentData = req.body;

    if (!checkoutId || !consignmentId) {
      return res
        .status(400)
        .json({ error: "Checkout ID and Consignment ID are required" });
    }

    if (!consignmentData || typeof consignmentData !== "object") {
      return res
        .status(400)
        .json({ error: "Valid consignment data is required" });
    }

    try {
      console.log(
        `Updating consignment for Checkout ID: ${checkoutId}, Consignment ID: ${consignmentId}`
      );

      const response = await axios.put(
        `${BASE_URL}/checkouts/${checkoutId}/consignments/${consignmentId}`,
        consignmentData,
        {
          headers: {
            "X-Auth-Token": ACCESS_TOKEN,
            "Content-Type": "application/json",
            Accept: "application/json",
          },
        }
      );

      res.json(response.data);
    } catch (error) {
      console.error(
        "Error updating consignment:",
        error.response?.data || error.message
      );
      res.status(error.response?.status || 500).json({
        error: "Failed to update consignment",
        details: error.response?.data || error.message,
      });
    }
  }
);

// API to Add Billing Address
app.post("/api/checkouts/:id/billing-address", async (req, res) => {
  const checkoutId = req.params.id;
  const billingData = req.body;

  if (!billingData) {
    return res.status(400).json({ error: "Billing data is required" });
  }

  try {
    console.log(`Adding billing address for Checkout ID: ${checkoutId}`);

    const response = await axios.post(
      `${BASE_URL}/checkouts/${checkoutId}/billing-address`,
      billingData,
      {
        headers: {
          "X-Auth-Token": ACCESS_TOKEN,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      }
    );

    res.json(response.data);
  } catch (error) {
    console.error(
      "Error adding billing address:",
      error.response?.data || error.message
    );
    res.status(error.response?.status || 500).json({
      error: "Failed to add billing address",
      details: error.response?.data || error.message,
    });
  }
});

//API to update Billing Address
app.put(
  "/api/checkouts/:checkoutId/billing-address/:addressId",
  async (req, res) => {
    const { checkoutId, addressId } = req.params;
    const billingData = req.body;

    if (!billingData || typeof billingData !== "object") {
      return res.status(400).json({ error: "Valid billing data is required" });
    }

    try {
      console.log(
        `Updating billing address for Checkout ID: ${checkoutId}, Address ID: ${addressId}`
      );

      const response = await axios.put(
        `${BASE_URL}/checkouts/${checkoutId}/billing-address/${addressId}`,
        billingData,
        {
          headers: {
            "X-Auth-Token": ACCESS_TOKEN,
            "Content-Type": "application/json",
            Accept: "application/json",
          },
        }
      );

      res.json(response.data);
    } catch (error) {
      console.error(
        "Error updating billing address:",
        error.response?.data || error.message
      );
      res.status(error.response?.status || 500).json({
        error: "Failed to update billing address",
        details: error.response?.data || error.message,
      });
    }
  }
);

//Add the Pickup Method API
app.post("/api/pickup-options", async (req, res) => {
  const pickupOptions = req.body;

  if (!pickupOptions || pickupOptions.length === 0) {
    return res.status(400).json({ error: "Pickup Options data is required" });
  }

  try {
    const response = await axios.post(
      `${BASE_URL}/pickup/options`,
      pickupOptions,
      {
        headers: {
          "X-Auth-Token": ACCESS_TOKEN,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      }
    );

    res.json(response.data);
  } catch (error) {
    console.error(
      "Error Fetching Pickup Options:",
      error.response?.data || error.message
    );
    res.status(error.response?.status || 500).json({
      error: "Failed to Fetch Pickup Options",
      details: error.response?.data || error.message,
    });
  }
});

//API for Get Cart ID
app.get("/api/carts", async (req, res) => {
  try {
    console.log(
      `Fetching cart data from Storefront API: ${STOREFRONT_CART_URL}`
    );

    const response = await axios.get(STOREFRONT_CART_URL, {
      headers: {
        "X-Auth-Token": ACCESS_TOKEN,
        "Content-type": "application/json",
        Accept: "application/json",
        credentials: "include",
      },
    });

    res.json(response.data);
  } catch (error) {
    console.error(
      "Error fetching cart:",
      error.response?.data || error.message
    );
    res.status(error.response?.status || 500).json({
      error: "Failed to fetch cart",
      details: error.response?.data || error.message,
    });
  }
});

//API for Apply Coupon Code
app.post("/api/checkouts/:id/coupons", async (req, res) => {
  const checkoutId = req.params.id;
  const { coupon_code, version } = req.body;

  if (!checkoutId) {
    return res.status(400).json({ error: "Checkout ID is required" });
  }

  if (!coupon_code) {
    return res.status(400).json({ error: "Coupon code is required" });
  }

  try {
    console.log(
      `Applying coupon code: ${coupon_code} to Checkout ID: ${checkoutId}`
    );

    const response = await axios.post(
      `${BASE_URL}/checkouts/${checkoutId}/coupons`,
      { coupon_code, version },
      {
        headers: {
          "X-Auth-Token": ACCESS_TOKEN,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      }
    );

    res.json(response.data);
  } catch (error) {
    console.error(
      "Error applying coupon code:",
      error.response?.data || error.message
    );

    res.status(error.response?.status || 500).json({
      error: "Failed to apply coupon code",
      details: error.response?.data || error.message,
    });
  }
});

//API for Remove Coupon Code
app.delete("/api/checkouts/:id/coupons/:couponCode", async (req, res) => {
  const checkoutId = req.params.id;
  const couponCode = req.params.couponCode;

  if (!checkoutId) {
    return res.status(400).json({ error: "Checkout ID is required" });
  }

  if (!couponCode) {
    return res.status(400).json({ error: "Coupon code is required" });
  }
  try {
    const response = await axios.delete(
      `${BASE_URL}/checkouts/${checkoutId}/coupons/${couponCode}`,
      {
        headers: {
          "X-Auth-Token": ACCESS_TOKEN,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      }
    );

    res.json(response.data);
  } catch (error) {
    console.error(
      "Error removing coupon code:",
      error.response?.data || error.message
    );

    res.status(error.response?.status || 500).json({
      error: "Failed to remove coupon code",
      details: error.response?.data || error.message,
    });
  }
});

//API for Customer Address
app.get("/api/customers/:id/addresses", async (req, res) => {
  const customerId = req.params.id;
  const endpoint = `customers/${customerId}/addresses`;

  try {
    console.log(`Fetching customer addresses from: ${BASE_URLV2}/${endpoint}`);

    const response = await axios.get(`${BASE_URLV2}/${endpoint}`, {
      headers: {
        "X-Auth-Token": ACCESS_TOKEN,
        "Content-Type": "application/json",
      },
    });

    // If the response is in XML format, convert it to JSON using xml2js
    if (typeof response.data === "string" && response.data.startsWith("<")) {
      const { parseStringPromise } = require("xml2js");
      const jsonData = await parseStringPromise(response.data, {
        explicitArray: false,
      });
      res.json(jsonData);
    } else {
      res.json(response.data); // If already in JSON, return as is
    }
  } catch (error) {
    console.error(
      "Error fetching customer addresses:",
      error.response?.data || error.message
    );
    res.status(error.response?.status || 500).json({
      error: "Failed to fetch customer addresses",
      details: error.response?.data || error.message,
    });
  }
});

// Get Payment Methods with checkoutID
app.get("/api/payments", async (req, res) => {
  const { checkout_id } = req.query; // Extract checkoutID from query params

  try {
    if (!checkout_id) {
      return res.status(400).json({ error: "checkout_id is required" });
    }

    const response = await axios.get(`${BASE_URL}/payments/methods`, {
      headers: {
        "X-Auth-Token": ACCESS_TOKEN,
        "Content-Type": "application/json",
      },
      params: { checkout_id: checkout_id }, // Pass checkoutID as a query parameter
    });

    res.json(response.data);
  } catch (error) {
    console.error(
      "Error fetching payment methods:",
      error.response?.data || error.message
    );
    res.status(error.response?.status || 500).json({
      error: "Failed to fetch payment data",
      details: error.response?.data || error.message,
    });
  }
});

// Place Order API Route
app.post("/api/checkouts/:id/orders", async (req, res) => {
  const checkoutId = req.params.id;
  const { payment } = req.body;

  if (!payment?.provider_id) {
    return res.status(400).json({ error: "Payment provider is required" });
  }

  try {
    console.log(`Placing order for Checkout ID: ${checkoutId}`);
    console.log("Received Payment Data:", payment);

    const response = await axios.post(
      `${BASE_URL}/checkouts/${checkoutId}/orders`,
      { payment },
      {
        headers: {
          "X-Auth-Token": ACCESS_TOKEN,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      }
    );

    res.json(response.data);
  } catch (error) {
    console.error(
      "Error placing order:",
      error.response?.data || error.message
    );
    res.status(error.response?.status || 500).json({
      error: "Failed to place order",
      details: error.response?.data || error.message,
    });
  }
});

//Get Payment Access Token API
app.post("/api/access_tokens", async (req, res) => {
  try {
    const { orderId } = req.body;
    if (!orderId) {
      return res.status(400).json({ error: "Order ID is required" });
    }

    const response = await axios.post(
      `${BASE_URL}/payments/access_tokens`,
      { order: { id: orderId } },
      {
        headers: {
          "Content-Type": "application/json",
          "X-Auth-Token": ACCESS_TOKEN,
        },
      }
    );

    const accessToken = response.data;

    console.log("BigCommerce API Response:", accessToken?.data?.id);

    if (!accessToken) {
      return res
        .status(500)
        .json({ error: "Failed to get payment access token" });
    }

    res.json({ accessToken });
  } catch (error) {
    console.error(
      "Error getting payment access token:",
      error.response?.data || error.message
    );
    res.status(error.response?.status || 500).json({
      error: error.response?.data?.message || "Internal Server Error",
    });
  }
});

// Process Payment API
app.post("/api/payments", async (req, res) => {
  try {
    const { orderID, paymentInstrument, accessToken } = req.body;

    if (!orderID || !paymentInstrument || !accessToken) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    // Process payment
    const response = await axios.post(
      `https://payments.bigcommerce.com/stores/${process.env.VITE_APP_STORE_ID}/payments`,
      paymentInstrument,
      {
        headers: {
          Accept: "application/vnd.bc.v1+json",
          Authorization: `PAT ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    res.json({ message: "Payment successful", data: response.data });
  } catch (error) {
    console.error("Error processing payment:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

//Klviyo the API for create Events with pickup store details
app.post("/api/track-event", async (req, res) => {
  console.log("Incoming request to /api/events");
  console.log("Headers:", req.headers);
  console.log("Body:", JSON.stringify(req.body, null, 2));

  try {
    // Extract event details from the request body
    const eventData = req.body;

    // Validate required fields
    if (
      !eventData ||
      !eventData.data ||
      !eventData.data.attributes ||
      !eventData.data.attributes.metric ||
      !eventData.data.attributes.profile
    ) {
      return res.status(400).json({ error: "Invalid event data structure" });
    }

    // Send the request to Klaviyo API
    const response = await axios.post(
      "https://a.klaviyo.com/api/events",
      eventData,
      {
        headers: {
          revision: "2025-01-15",
          "Content-Type": "application/vnd.api+json",
          Authorization: `Klaviyo-API-Key ${process.env.KLAVIYO_API_KEY}`,
        },
      }
    );

    // Send back the response from Klaviyo
    res.status(response.status).json(response.data);
  } catch (error) {
    console.error(
      "Error sending event to Klaviyo:",
      error.response?.data || error.message
    );
    res.status(error.response?.status || 500).json({
      error: error.response?.data || "Failed to send event to Klaviyo",
    });
  }
});

//API Route for get all store locations

app.get("/api/inventory/locations", async (req, res) => {
  try {
    const response = await axios.get(`${BASE_URL}/inventory/locations`, {
      headers: {
        "X-Auth-Token": ACCESS_TOKEN,
        "Content-Type": "application/json",
      },
    });
    res.json(response.data);
  } catch (error) {
    console.error(
      "Error fetching inventory locations:",
      error.response?.data || error.message
    );
    res
      .status(error.response?.status || 500)
      .json({ error: "Failed to fetch inventory locations" });
  }
});

// API Routes
app.get("/api/checkouts/:id", (req, res) =>
  fetchBigCommerceData(`checkouts/${req.params.id}`, res)
);

//Braintree Paypal Payment Setup
// Generate Client Token for Frontend
app.get("/api/braintree/client-token", async (req, res) => {
  try {
    gateway.clientToken.generate({}, (err, response) => {
      if (err) {
        console.error("Braintree Token Error:", err);
        return res.status(500).json({ error: err.message });
      }
      res.json({ clientToken: response.clientToken });
    });
  } catch (error) {
    console.error("Unexpected Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Process the Payment
// Create a Transaction (Redirects to PayPal)
app.post("/api/braintree/checkout", async (req, res) => {
  const { paymentMethodNonce, amount } = req.body;

  try {
    const result = await gateway.transaction.sale({
      amount: amount.toString(),
      paymentMethodNonce,
      options: {
        submitForSettlement: true,
      },
    });

    if (result.success) {
      res.json({
        success: true,
        transactionId: result.transaction.id,
      });
    } else {
      console.error("Braintree Pyament gateway Error:", result.message);
      res.status(400).json({
        success: false,
        error: result.message,
      });
    }
  } catch (error) {
    console.error("Server Error:", error);
    res.status(500).json({
      success: false,
      error: "Server error during transaction",
    });
  }
});

//Create order
app.post("/api/bigcommerce/create-order", async (req, res) => {
  try {
    const orderPayload = req.body;

    const response = await fetch(`${BASE_URLV2}/orders`, {
      method: "POST",
      headers: {
        "X-Auth-Token": ACCESS_TOKEN,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(orderPayload),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("BigCommerce error:", data);
      return res
        .status(response.status)
        .json({ success: false, message: data });
    }

    res.status(200).json({ success: true, data });
  } catch (err) {
    console.error("Server error:", err.message);
    res
      .status(500)
      .json({ success: false, message: "Server error", error: err.message });
  }
});

//Create checkout token for redirection order confirmation page
app.post("/api/checkouts/:id/checkout-token", async (req, res) => {
  const { id: checkoutID } = req.params;

  if (!checkoutID) {
    return res.status(400).json({ error: "Missing checkoutId" });
  }

  let data = JSON.stringify({
    maxUses: 1,
    ttl: 2,
  });

  try {
    const response = await axios.post(
      `${BASE_URL}/checkouts/${checkoutID}/token`,
      JSON.stringify({
        maxUses: 1,
        ttl: 2,
      }),
      {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "X-Auth-Token": ACCESS_TOKEN,
        },
      }
    );

    res.status(200).json(response.data);
  } catch (error) {
    console.error(
      "Checkout Token Error:",
      error.response?.data || error.message
    );
    res.status(500).json({ error: error.response?.data || error.message });
  }
});

//Customer Login
app.post("/api/login", async (req, res) => {
  const { email, password, guestCartEntityId } = req.body;

  const query = `
  mutation {
    login(
      email: "${email}"
      password: "${password}"
      guestCartEntityId: "${guestCartEntityId}"
    ) {
      customer {
        addressCount
        customerGroupId
        email
        entityId
        firstName
        lastName
      }
      result
    }
  }
`;

  try {
    const response = await axios.post(
      "https://headless-m4.mybigcommerce.com/graphql",
      { query },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${BIGCOMMERCE_TOKEN}`, // store in .env
        },
        withCredentials: true,
      }
    );

    // ✅ Pass cookie headers back to client
    const setCookieHeader = response.headers["set-cookie"];
    if (setCookieHeader) {
      res.setHeader("Set-Cookie", setCookieHeader);
    }

    res.status(200).json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.response?.data || error.message });
  }
});
// Customer Logout
app.post("/api/logout", async (req, res) => {
  const query = `
    mutation Logout {
      logout {
        result
      }
    }
  `;

  try {
    const response = await axios.post(
      "https://headless-m4.mybigcommerce.com/graphql",
      { query },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${BIGCOMMERCE_TOKEN}`,
          Cookie: req.headers.cookie,
        },
        withCredentials: true,
      }
    );

    // ✅ Clear cookies BEFORE sending response
    res.clearCookie("SHOP_TOKEN", {
      path: "/",
      domain: "localhost", // ✅ Not a full URL — just the domain
      secure: false, // ✅ Use false for localhost
      sameSite: "Lax",
    });
    res.clearCookie("SHOP_SESSION_TOKEN", {
      path: "/",
      domain: "localhost",
      secure: false,
      sameSite: "Lax",
    });
    res.clearCookie("SHOP_SESSION_ROTATION_TOKEN", {
      path: "/",
      domain: "localhost",
      secure: false,
      sameSite: "Lax",
    });

    // ✅ THEN send response
    res.status(200).json(response.data);
  } catch (error) {
    console.error("Logout error:", error.response?.data || error.message);
    res.status(500).json({ error: error.response?.data || error.message });
  }
});

// Catch-all route (should be at the very bottom)
app.use("*", (req, res) => {
  res.status(404).json({ error: "Not Found" });
});

app.get("/api/test", (req, res) => {
  res.json({ message: "Test route is working!" });
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
