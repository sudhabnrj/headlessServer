// api/index.js
import app from "../server";
import serverless from "serverless-http";

export default serverless(app);
